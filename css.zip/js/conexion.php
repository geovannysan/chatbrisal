<?php
define('USER', 'netbot_root');
define('PASSWORD', 'Chtl_1985/');
define('HOST', 'localhost');
define('DATABASE', 'netbot_chatbrisana');
try {
    $connection = new PDO("mysql:host=".HOST.";dbname=".DATABASE, USER, PASSWORD);
} catch (PDOException $e) {
    exit("Error: " . $e->getMessage());
}
?>